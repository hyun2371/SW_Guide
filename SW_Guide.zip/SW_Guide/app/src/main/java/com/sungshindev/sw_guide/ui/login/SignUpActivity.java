package com.sungshindev.sw_guide.ui.login;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.sungshindev.sw_guide.R;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
    }
}
