package com.sungshindev.sw_guide.data;

public class Question {
    String q;

    public String getQ(){
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }

    public Question(String q){
        this.q = q;
    }
}
